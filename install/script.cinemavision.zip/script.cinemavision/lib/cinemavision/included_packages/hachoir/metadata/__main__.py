from hachoir.metadata.main import main
main()
